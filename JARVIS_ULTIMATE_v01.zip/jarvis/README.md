# JARVIS ULTIMATE — Android prototype

This is the first installable-app prototype source for Android 8+ (tested target: Android 14). It has a sci-fi interface, Russian speech recognition while the app is open, spoken replies, time, YouTube/browser launch, music-app intent, and a safe phone dialer intent.

## Important limits in v0.1
- It does **not** continuously listen for the wake phrase while the screen is off.
- It opens the dialer; it does not place calls automatically.
- AI chat and cloud memory are not connected yet. Do not put a private API key in an APK.
- Speech recognition availability/language depends on the speech service installed on the phone.

## Build APK
Open this folder in Android Studio and choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK will appear at `app/build/outputs/apk/debug/app-debug.apk`.

Or push the project to a GitHub repository. The included workflow builds a debug APK and attaches it to the workflow run as an artifact.
