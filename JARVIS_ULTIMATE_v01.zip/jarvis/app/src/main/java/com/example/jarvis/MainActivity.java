package com.example.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private TextView status, heard;
    private Button listen;
    private boolean ready = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(0xFF050B14);
        getWindow().setNavigationBarColor(0xFF050B14);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("ru", "RU"));
                ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(0.92f);
            }
        });
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { status.setText("СЛУШАЮ ВАС"); }
                public void onBeginningOfSpeech() { status.setText("РАСПОЗНАЮ РЕЧЬ"); }
                public void onRmsChanged(float r) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { status.setText("ОБРАБОТКА"); }
                public void onError(int e) { status.setText("ГОТОВ К КОМАНДЕ"); listen.setText("НАЧАТЬ ГОВОРИТЬ"); }
                public void onResults(Bundle b) {
                    ArrayList<String> matches = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) { heard.setText("» " + matches.get(0)); handleCommand(matches.get(0)); }
                    listen.setText("НАЧАТЬ ГОВОРИТЬ"); status.setText("ГОТОВ К КОМАНДЕ");
                }
                public void onPartialResults(Bundle b) {}
                public void onEvent(int t, Bundle p) {}
            });
        } else status.setText("РАСПОЗНАВАНИЕ РЕЧИ НЕДОСТУПНО");
        listen.setOnClickListener(v -> startListening());
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(28, 38, 28, 24); root.setBackgroundColor(0xFF050B14);
        TextView brand = new TextView(this); brand.setText("J.A.R.V.I.S."); brand.setTextColor(0xFF62DFFF); brand.setTextSize(29); brand.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL)); brand.setLetterSpacing(0.22f); brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(-1, 58));
        TextView sub = new TextView(this); sub.setText("PERSONAL ASSISTANT  •  PROTOTYPE 01"); sub.setTextColor(0xFF668A9C); sub.setTextSize(10); sub.setLetterSpacing(0.16f); sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 32));
        View orb = new OrbView(this); LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(270, 270); op.setMargins(0, 30, 0, 25); root.addView(orb, op);
        status = new TextView(this); status.setText("ГОТОВ К КОМАНДЕ"); status.setTextColor(0xFF62DFFF); status.setTextSize(13); status.setLetterSpacing(0.12f); status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 38));
        heard = new TextView(this); heard.setText("Скажите команду после нажатия кнопки"); heard.setTextColor(0xFF9BB5C2); heard.setTextSize(14); heard.setGravity(Gravity.CENTER); heard.setPadding(10, 12, 10, 12);
        root.addView(heard, new LinearLayout.LayoutParams(-1, 62));
        listen = new Button(this); listen.setText("НАЧАТЬ ГОВОРИТЬ"); listen.setTextColor(0xFF06121B); listen.setTextSize(13); listen.setLetterSpacing(0.08f);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xFF54DFFF); bg.setCornerRadius(50); listen.setBackground(bg);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 58); bp.setMargins(0, 20, 0, 20); root.addView(listen, bp);
        TextView hint = new TextView(this); hint.setText("КОМАНДЫ\n«Позвони [имя]»  •  «Открой YouTube»\n«Который час?»  •  «Включи музыку»\n\nМикрофон включается только после нажатия кнопки."); hint.setTextColor(0xFF668A9C); hint.setTextSize(12); hint.setGravity(Gravity.CENTER); hint.setLineSpacing(7, 1f); root.addView(hint);
        setContentView(root);
    }

    private void startListening() {
        if (recognizer == null) { Toast.makeText(this, "На устройстве нет службы распознавания речи", Toast.LENGTH_LONG).show(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7); return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        listen.setText("СЛУШАЮ..."); recognizer.startListening(i);
    }

    private void say(String text) { if (ready && tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis"); }

    private void handleCommand(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).replace("джарвис", "").trim();
        if (s.startsWith("позвони ") || s.startsWith("набери ")) {
            String who = s.replaceFirst("^(позвони|набери)\\s+", "").trim();
            say("Открываю набор номера для контакта " + who);
            Intent call = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"));
            try { startActivity(call); } catch (Exception e) { say("Не удалось открыть телефон"); }
        } else if (s.contains("который час") || s.equals("время") || s.contains("сколько времени")) {
            String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()); heard.setText("Сейчас " + time); say("Сейчас " + time);
        } else if (s.contains("открой youtube") || s.contains("запусти youtube")) {
            launch("com.google.android.youtube", "Открываю YouTube");
        } else if (s.contains("открой chrome") || s.contains("открой браузер")) {
            launch("com.android.chrome", "Открываю браузер");
        } else if (s.contains("включи музыку") || s.contains("музыку")) {
            say("Открываю музыкальное приложение");
            Intent m = new Intent("android.intent.action.MUSIC_PLAYER");
            try { startActivity(m); } catch (Exception e) { say("Музыкальное приложение не найдено"); }
        } else if (s.contains("привет")) { say("Здравствуйте. Джарвис к вашим услугам."); }
        else { say("Команда пока не поддерживается. Попробуйте открыть YouTube, включить музыку или спросить время."); }
    }

    private void launch(String pkg, String response) {
        say(response); Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) startActivity(i); else say("Приложение не найдено");
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == 7 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else Toast.makeText(this, "Для голосовых команд нужен доступ к микрофону", Toast.LENGTH_LONG).show();
    }
    @Override protected void onDestroy() { if (recognizer != null) recognizer.destroy(); if (tts != null) tts.shutdown(); super.onDestroy(); }

    private static class OrbView extends View {
        Paint p = new Paint(3);
        OrbView(android.content.Context c) { super(c); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float x=getWidth()/2f, y=getHeight()/2f; p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
            for(int n=0;n<5;n++){ p.setColor(n%2==0?0x8854DFFF:0x4437A8D0); c.drawCircle(x,y,45+n*21,p); }
            p.setStyle(Paint.Style.FILL); p.setColor(0xFF54DFFF); c.drawCircle(x,y,7,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xFF2B7999);
            for(int a=0;a<360;a+=30){ double r=Math.toRadians(a); float x1=x+(float)Math.cos(r)*137, y1=y+(float)Math.sin(r)*137; float x2=x+(float)Math.cos(r)*128, y2=y+(float)Math.sin(r)*128; c.drawLine(x1,y1,x2,y2,p); }
        }
    }
}
